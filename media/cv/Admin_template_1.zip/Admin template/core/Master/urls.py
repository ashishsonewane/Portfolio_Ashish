from django.urls import path
from . import views
urlpatterns = [
      path('',views.adminlogin,name='login'),
      path('logout',views.adminlogout,name='logout'),
      path('index',views.index,name='index'),
      path('settings',views.settings,name='settings'),
      path('search_results',views.search_results,name='search_results'),
      
      path('gallary_table',views.gallary_table,name='gallary_table'),
      path('add_gallary',views.add_gallary,name='add_gallary'),
      path('delete_gallary/<int:id>',views.delete_gallary,name='delete_gallary'),
      path('gallary_update/<int:id>',views.gallary_update,name='gallary_update'),

      path('add_title',views.add_title,name='add_title'),
      path('title_table',views.title_table,name='title_table'),
      path('edit_title/<int:id>',views.edit_title,name='edit_title'),
      path('delete_title/<int:id>',views.delete_title,name='delete_title'),

  
]