from .models import *
from imaplib import _Authenticator
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,logout
from django.contrib import auth
from django.db.models import Q


def adminlogin(request):
    if request.method == 'POST':
        username = request.POST.get('email')
        password = request.POST.get('password')
        print(username)
        print(password)
        user = authenticate(username=username, password=password)
        print(user)
        if user is not None :
            if user.is_superuser == True and user.is_staff == True:
                auth.login(request, user)
                return redirect('index')
            else:
                return redirect('/')
        else:
            return redirect('/')
    return render(request, 'login.html')

def adminlogout(request):
    user = request.user
    logout(request)
    return redirect('login')

def search_results(request):
    query = request.GET.get('q')  # Get the search query from the request
    results = []
    if query:
        results = AddImage.objects.filter(
            Q(name__icontains=query) | Q(name__icontains=query)
        )
    context = {
        'query': query,
        'results': results
    }
    return render(request, 'search_results.html', context)


def index(request):
    return render(request,'index.html')

def settings(request):
    return render(request,'settings.html')

def gallary_table(request):
    data=AddImage.objects.all()
    return render(request,'gallary_table.html',{'data':data})

def add_gallary(request):
    try:
        if request.method =='POST':
            namef=request.POST['name']
            imagef=request.FILES['image']
            gallaryobj=AddImage.objects.create(name=namef,image=imagef)
            return redirect('/gallary_table')
        return render(request,'add_gallary.html')
    except:
        return redirect('/gallary_table')

def delete_gallary(request,id):
    data=AddImage.objects.get(id=id)
    data.delete()
    return redirect('gallary_table')

def gallary_update(request,id):
    gallaryobj=AddImage.objects.get(id=id)
    if request.method =='POST':
        namef=request.POST['name']
        imagef=request.FILES.get('image')
        if imagef:
            gallaryobj.image=imagef
        else:
            pass
        gallaryobj.name=namef
        gallaryobj.save()
        return redirect('gallary_table')
    return render(request,'gallary_update.html',{'gallaryobj':gallaryobj})


def  title_table(request):
    data=Secondimage.objects.all()
    return render(request,'title_table.html',{'data':data})


def add_title(request):
    if request.method == 'POST':
        title = request.POST['title']
        image=request.FILES['image']
        description=request.POST['description']
        titelobj=Secondimage.objects.create(title=title,image=image,description=description)
        return redirect('title_table')

def delete_title(request,id):
    data=Secondimage.objects.get(id=id)
    data.delete()
    return redirect('title_table')   

def edit_title(request,id):
    titelobj=Secondimage.objects.get(id=id)
    if request.method == 'POST':
        title = request.POST['title']
        imagef=request.FILES.get('image')
        if imagef:
            titelobj.image=imagef
        else:
            pass
        description=request.POST['description']
        titelobj.title=title
        titelobj.description=description
        titelobj.save()
        return redirect(title_table)
    return render(request,'edit_title.html',{'titelobj':titelobj})






