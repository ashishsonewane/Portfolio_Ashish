from django.db import models

# Create your models here.
class AddImage(models.Model):
    name = models.CharField(max_length=100)
    image=models.ImageField(upload_to='Gallary',blank=True,null=True)

class Secondimage(models.Model):
    image=models.ImageField(upload_to='Gallary_1',blank=True,null=True)
    title = models.CharField(max_length=200)
    description = models.TextField()
